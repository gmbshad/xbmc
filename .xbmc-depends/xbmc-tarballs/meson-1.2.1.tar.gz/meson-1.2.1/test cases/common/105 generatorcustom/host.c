#include "res1-cpp.h"

int main(void) {
    #ifdef res1
        return 0;
    #else
        return 1;
    #endif
}
