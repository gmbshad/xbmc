int func3_in_obj(void) {
    return 0;
}
