#pragma once

int doStuff(void);
