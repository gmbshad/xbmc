#include <stdint.h>
#include <stdio.h>

int32_t cmTestFunc(void);

int main(void)
{
    if (cmTestFunc() > 4200)
    {
        printf("Test success.\n");
        return 0;
    }
    else
    {
        printf("Test failure.\n");
        return 1;
    }
}
