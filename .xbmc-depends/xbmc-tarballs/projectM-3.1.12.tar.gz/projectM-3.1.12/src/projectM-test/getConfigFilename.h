//
// File:   getConfigFilename.h
//
// Author: fatray
//
// Created on 05 December 2007, 23:39
//

#ifndef _GETCONFIGFILENAME_H
#define	_GETCONFIGFILENAME_H

//FIXME: define this here?  in .cpp? or somewhere else?
#define CONFIG_FILE "/share/projectM/config.inp"

// get the full pathname of a configfile
std::string getConfigFilename();

#endif	/* _GETCONFIGFILENAME_H */
