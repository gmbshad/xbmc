#!/bin/sh

autoreconf -f -i -s

cd man
./make.sh
