#[derive(Debug)]
pub(crate) enum NotificationLevel {
    Verbose,
    Info,
    Warn,
    Error,
    Debug,
}
