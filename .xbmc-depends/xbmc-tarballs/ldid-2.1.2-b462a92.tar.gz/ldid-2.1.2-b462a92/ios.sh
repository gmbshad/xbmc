#!/bin/bash
./make.sh true
