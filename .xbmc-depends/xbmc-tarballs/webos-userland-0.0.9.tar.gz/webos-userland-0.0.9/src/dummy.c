void dummy(void) {}
void *dummy_data;