#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int LGNC_DL_Initialize();

int LGNC_DL_IsInitialized();

void LGNC_DL_Finalize();

#ifdef __cplusplus
}
#endif