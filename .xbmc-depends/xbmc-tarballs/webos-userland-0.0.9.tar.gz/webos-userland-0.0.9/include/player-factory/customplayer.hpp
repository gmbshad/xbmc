#pragma once

#include <player-factory/abstractplayer.hpp>

namespace mediapipeline {

class CustomPlayer : public AbstractPlayer {

};

}
