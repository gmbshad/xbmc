#pragma once

namespace mediapipeline {

class Pipeline {

};

}
