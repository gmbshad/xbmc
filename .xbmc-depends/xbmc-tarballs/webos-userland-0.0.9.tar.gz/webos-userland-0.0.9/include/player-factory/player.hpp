#pragma once

namespace mediapipeline {

class Player {

};

}
