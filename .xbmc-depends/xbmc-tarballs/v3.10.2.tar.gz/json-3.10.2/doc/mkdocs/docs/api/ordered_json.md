# ordered_json

```cpp
using ordered_json = basic_json<nlohmann::ordered_map>;
```
