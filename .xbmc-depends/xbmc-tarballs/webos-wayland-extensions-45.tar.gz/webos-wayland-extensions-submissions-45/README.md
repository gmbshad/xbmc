webos-wayland-extensions
========================

Summary
-------
Wayland protocol extensions for webOS

Description
-----------
This package contains Wayland protocol extensions(xml) designed for webOS.
