# mp42hevc
```
MP4 To HEVC File Converter - Version 1.0
(Bento4 Version 1.6.0.0)
(c) 2002-2014 Axiomatic Systems, LLC

usage: mp42hevc [options] <input> <output>
  Options:
  --key <hex>: 128-bit decryption key (in hex: 32 chars)
```
