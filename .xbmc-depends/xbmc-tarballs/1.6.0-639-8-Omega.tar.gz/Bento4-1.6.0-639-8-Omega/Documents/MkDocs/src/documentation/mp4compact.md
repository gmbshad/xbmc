# mp4compact
```
MP4 Compacter - Version 1.0
(Bento4 Version 1.6.0.0)
(c) 2002-2011 Axiomatic Systems, LLC

usage: mp4compact [options] <input> <output>
Options:
  --verbose
```
