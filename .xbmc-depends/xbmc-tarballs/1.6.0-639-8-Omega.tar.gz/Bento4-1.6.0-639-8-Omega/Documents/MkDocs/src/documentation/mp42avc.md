# mp42avc
```
MP4 To AVC File Converter - Version 1.0
(Bento4 Version 1.6.0.0)
(c) 2002-2009 Axiomatic Systems, LLC

usage: mp42avc [options] <input> <output>
  Options:
  --key <hex>: 128-bit decryption key (in hex: 32 chars)
```
