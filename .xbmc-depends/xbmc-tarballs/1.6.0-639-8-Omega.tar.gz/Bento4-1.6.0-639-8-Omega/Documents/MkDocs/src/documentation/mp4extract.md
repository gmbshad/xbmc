# mp4extract
```
MP4 Atom Extractor - Version 1.0
(Bento4 Version 1.6.0.0)
(c) 2002-2008 Axiomatic Systems, LLC

usage: mp4extract [options] <atom_path> <input> <output>
    options:
    --payload-only : omit the atom header
```
