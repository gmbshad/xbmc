ABOUT BENTO4
============

Bento4 is developed by Axiomatic Systems LLC in San Francisco, California.

**This software is available under two different licenses**  
For applications that are entirely distributable under the terms of the [GPL](http://www.gnu.org/licenses/gpl-2.0-standalone.html), the Bento4 GPL license applies.
For applications that cannot be entirely distributable under the terms of the GPL (either the application, or code modules linked with the application are not compatible with the terms of the GPL licence), a non-GPL commercial license is available from Axiomatic Systems LLC.
Contact Gilles Boccon-Gibod (licensing@axiosys.com or bok@bok.net) for more information.