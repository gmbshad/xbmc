#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

extern "C" {

void A();

void B();

void C();

void D();

} // extern "C"
