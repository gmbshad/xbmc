#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

extern "C" {

extern char MUT_GLOBAL_ARRAY[128];

extern const char CONST_GLOBAL_ARRAY[128];

} // extern "C"
