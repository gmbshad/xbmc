#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct Dummy {
  int32_t x;
  float y;
} Dummy;

void root(struct Dummy d);
