# bitvec_helpers
Bitstream reader/writer helpers.

## Features
- `bitvec`: Expose [bitvec](https://github.com/ferrilab/bitvec) based reader, writer.
- `bitstream-io`: Expose [bitstream-io](https://github.com/tuffy/bitstream-io) based reader, writer.
