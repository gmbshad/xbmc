#!/bin/bash

echo password=pass
