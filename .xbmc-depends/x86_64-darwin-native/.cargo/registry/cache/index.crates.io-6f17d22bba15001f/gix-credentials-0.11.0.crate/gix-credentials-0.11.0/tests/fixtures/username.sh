#!/bin/bash

echo username=user
