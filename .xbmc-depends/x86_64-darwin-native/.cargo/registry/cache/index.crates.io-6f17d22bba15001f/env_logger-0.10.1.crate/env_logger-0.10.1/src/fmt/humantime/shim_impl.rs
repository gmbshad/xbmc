/*
Timestamps aren't available when we don't have a `humantime` dependency.
*/

pub(in crate::fmt) mod glob {}
