//! # Example: Custom Types (Derive API)
//!
//! ```rust
#![doc = include_str!("../../examples/typed-derive.rs")]
//! ```
//!
#![doc = include_str!("../../examples/typed-derive.md")]
