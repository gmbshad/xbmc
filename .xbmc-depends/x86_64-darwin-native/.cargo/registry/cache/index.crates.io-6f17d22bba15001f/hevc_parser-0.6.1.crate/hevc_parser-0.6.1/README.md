## HEVC format parser

Might never become a simple API, mostly for my own tools.