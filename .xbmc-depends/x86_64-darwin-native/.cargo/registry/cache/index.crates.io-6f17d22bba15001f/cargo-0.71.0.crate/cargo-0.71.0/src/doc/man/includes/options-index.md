{{#option "`--index` _index_"}}
The URL of the registry index to use.
{{/option}}
