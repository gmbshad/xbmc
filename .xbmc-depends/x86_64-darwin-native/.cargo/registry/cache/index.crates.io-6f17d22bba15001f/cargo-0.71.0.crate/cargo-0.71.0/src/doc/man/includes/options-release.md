{{#option "`-r`" "`--release`"}}
{{actionverb}} optimized artifacts with the `release` profile.
See also the `--profile` option for choosing a specific profile by name.
{{/option}}
