# Architecture Overview

See the
[nightly docs](https://doc.rust-lang.org/nightly/nightly-rustc/cargo/index.html)
for an overview of `cargo`s architecture and links out to further details.
