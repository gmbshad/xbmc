{{#option "`--ignore-rust-version`"}}
{{actionverb}} the target even if the selected Rust compiler is older than the
required Rust version as configured in the project's `rust-version` field.
{{/option}}
