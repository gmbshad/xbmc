# Implementing a Change

This chapter gives an overview of what you need to know in making a change to cargo.

If you feel something is missing that would help you, feel free to ask on
[Zulip](https://rust-lang.zulipchat.com/#narrow/stream/246057-t-cargo).
