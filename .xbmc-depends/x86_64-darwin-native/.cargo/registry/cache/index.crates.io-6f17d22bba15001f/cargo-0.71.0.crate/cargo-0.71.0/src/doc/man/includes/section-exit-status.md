## EXIT STATUS

* `0`: Cargo succeeded.
* `101`: Cargo failed to complete.
