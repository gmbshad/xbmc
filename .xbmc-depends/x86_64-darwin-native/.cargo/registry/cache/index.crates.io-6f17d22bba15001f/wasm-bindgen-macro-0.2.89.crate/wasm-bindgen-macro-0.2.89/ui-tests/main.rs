use wasm_bindgen::prelude::*;

#[wasm_bindgen(main)]
fn main() {}

#[wasm_bindgen(main)]
fn fail() {}
