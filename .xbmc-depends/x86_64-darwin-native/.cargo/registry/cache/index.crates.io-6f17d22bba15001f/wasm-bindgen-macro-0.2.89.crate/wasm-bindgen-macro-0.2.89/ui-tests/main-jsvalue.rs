use wasm_bindgen::prelude::*;

#[wasm_bindgen(main)]
fn main() -> Result<(), JsValue> {
    unimplemented!()
}

#[wasm_bindgen(main)]
fn fail() {}
