---
name: Bug report
about: Report a Bug / Melde einen Fehler
title: ''
labels: ''
assignees: ''

---

**Describe the bug / Beschreibe den Fehler**
A clear and concise description of what the bug is. 
Feel free to write in english or in german.


**Environment / Umgebung:**
 - Kodi version: [e.g. 18 or 19]
 - OS: [e.g. LibreELEC, OSMC, Android TV]
 - pvr.waipu version [e.g. 1.3.2]
 - inputstream.adaptive version [e.g. 0.5.2]
