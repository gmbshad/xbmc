# Extension PVR Kodi pour Freebox TV

[![Build and run tests](https://github.com/aassif/pvr.freebox/actions/workflows/build.yml/badge.svg?branch=Omega)](https://github.com/aassif/pvr.freebox/actions/workflows/build.yml)

Compatible Freebox Revolution, Freebox Mini 4K et Freebox Delta.

- Chaînes TV (IPTV + TNT).
- Guide des programmes.

Après autorisation via l'interface tactile du Freebox Server :

- Lecture des enregistrements.
- Programmation des enregistrements.

Plus d'informations sur la page [wiki](../../wiki).
