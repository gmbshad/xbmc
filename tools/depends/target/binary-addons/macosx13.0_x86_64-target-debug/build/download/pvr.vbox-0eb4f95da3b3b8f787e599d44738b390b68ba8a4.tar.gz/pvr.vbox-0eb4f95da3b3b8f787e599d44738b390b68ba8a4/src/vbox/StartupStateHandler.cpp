/*
 *  Copyright (C) 2015-2021 Team Kodi (https://kodi.tv)
 *  Copyright (C) 2015 Sam Stenvall
 *
 *  SPDX-License-Identifier: GPL-2.0-or-later
 *  See LICENSE.md for more information.
 */

#include "StartupStateHandler.h"

using namespace vbox;

const int StartupStateHandler::STATE_WAIT_TIMEOUT = 120;
