// Version information for the "BasicUsageEnvironment" library
// Copyright (c) 1996-2010 Live Networks, Inc.  All rights reserved.

#ifndef _BASICUSAGEENVIRONMENT_VERSION_HH
#define _BASICUSAGEENVIRONMENT_VERSION_HH

#define BASICUSAGEENVIRONMENT_LIBRARY_VERSION_STRING	"2010.03.16"
#define BASICUSAGEENVIRONMENT_LIBRARY_VERSION_INT		1268697600

#endif
