#include "EpgProvider.h"

std::mutex EpgProvider::sendEpgToKodiMutex;
